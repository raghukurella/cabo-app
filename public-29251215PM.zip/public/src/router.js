const routes = {
  "": "pages/landing.html",
  "#": "pages/landing.html",        // ⭐ ADD THIS
  "#/": "pages/landing.html",
  "#/login": "pages/login.html",
  "#/signup": "pages/signup.html",
  "#/profile": "pages/profile.html",
  "#/profile-more": "pages/profile-more.html",
  "#/my-profile": "pages/my-profile.html",
  "#/search": "pages/search.html",
  "#/security": "pages/security.html",

  "#/matchmaker": "pages/matchmaker.html",
  "#/profilevw": "pages/profile-view.html",
  "#/admin": "pages/admin.html"
};

async function loadPage() {

  const hash = window.location.hash || "#/";




  if (hash === "" || hash === "#") {
  window.location.hash = "#/";
  return;
  }



  const cleanHash = hash.replace(/\/+$/, ""); // remove trailing slash
  let page;

  // Handle dynamic profile route
  if (cleanHash.startsWith("#/profilevw/")) {
    page = routes["#/profilevw"];
  } else {
    page = routes[cleanHash] || routes["#/"];
  }

  const html = await fetch(page).then(res => res.text());
  const app = document.getElementById("app");
  app.innerHTML = html;

  // Import scripts AFTER HTML is injected
  if (cleanHash === "#/admin") {
    import("./admin.js");
  } else if (cleanHash.startsWith("#/matchmaker")) {
    import("./matchmaker.js");
  } else if (cleanHash.startsWith("#/profilevw/")) {
    import("./profile-view.js");
  }

  // Re-execute inline scripts
  const scripts = app.querySelectorAll("script");
  scripts.forEach(oldScript => {
    const newScript = document.createElement("script");

    for (const attr of oldScript.attributes) {
      newScript.setAttribute(attr.name, attr.value);
    }

    if (oldScript.textContent) {
      newScript.textContent = oldScript.textContent;
    }

    document.body.appendChild(newScript);
    oldScript.remove();
  });
}

window.addEventListener("hashchange", loadPage);
window.addEventListener("DOMContentLoaded", loadPage);