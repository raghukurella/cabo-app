    import { supabase } from "./supabase.js";

async function requireMatchmaker() {
  const gate = document.getElementById("matchmakerGate");
  const content = document.getElementById("matchmakerContent");

  gate.classList.add("hidden");
  content.classList.add("hidden");
  gate.textContent = "";

  const {
    data: { session }
  } = await supabase.auth.getSession();

  if (!session?.user) {
    gate.textContent = "You must be signed in to access matchmaker tools.";
    gate.classList.remove("hidden");
    return null;
  }

  const userId = session.user.id;

  const { data: mmRow, error } = await supabase
    .schema("cabo")
    .from("mm_matchmakers")
    .select("*")
    .eq("auth_user_id", userId)
    .maybeSingle();

  if (error) {
    console.error(error);
    gate.textContent = "Error checking matchmaker access.";
    gate.classList.remove("hidden");
    return null;
  }

  if (!mmRow) {
    gate.textContent = "You are not registered as a matchmaker.";
    gate.classList.remove("hidden");
    return null;
  }

  content.classList.remove("hidden");
  return mmRow;
}

async function loadPeople() {
  const peopleList = document.getElementById("peopleList");
  peopleList.innerHTML = '<div class="text-sm text-gray-500">Loading...</div>';

  const { data, error } = await supabase
    .schema("cabo")
    .from("mm_people")
    .select("*")
    .order("last_name", { ascending: true });

  if (error) {
    console.error(error);
    peopleList.innerHTML = '<div class="text-sm text-red-600">Error loading people.</div>';
    return;
  }

  if (!data || data.length === 0) {
    peopleList.innerHTML = '<div class="text-sm text-gray-500">No profiles found.</div>';
    return;
  }

  peopleList.innerHTML = "";
  data.forEach(renderPersonRow);
}

function renderPersonRow(p) {
  const container = document.createElement("div");
  container.className =
    "border rounded px-4 py-3 bg-white shadow-sm cursor-pointer";

  const name = `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim();

  container.innerHTML = `
    <div class="font-medium text-gray-900">${name || "(No name)"}</div>
    <div class="text-sm text-gray-600">${p.email || "No email"}</div>
  `;

  container.addEventListener("click", () => {
    // Remove highlight from all rows
    document.querySelectorAll(".person-selected")
      .forEach(el => el.classList.remove("person-selected"));

    // Highlight this row
    container.classList.add("person-selected");

    // Save scroll position so we can restore it later
    sessionStorage.setItem("mm_scroll", window.scrollY.toString());

    // Navigate to profile
    window.location.hash = `#/profilevw/${p.id}`;
  });

  document.getElementById("peopleList").appendChild(container);
}

async function initMatchmaker() {
  const ok = await requireMatchmaker();
  if (!ok) return;

  // Attach filter button listener AFTER HTML is loaded
  document.getElementById("applyFilters")
    .addEventListener("click", loadPeopleWithFilters);

  // Load initial list (unfiltered or filtered)
  await loadPeopleWithFilters();

  // Optional: restore scroll position
  const savedScroll = sessionStorage.getItem("mm_scroll");
  if (savedScroll) {
    window.scrollTo(0, parseInt(savedScroll, 10));
    sessionStorage.removeItem("mm_scroll");
  }
}

function renderPeopleList(people) {
  const list = document.getElementById("peopleList");
  list.innerHTML = "";

  if (!people || people.length === 0) {
    list.innerHTML = `<div class="text-gray-500 text-sm">No results found.</div>`;
    return;
  }

  people.forEach(p => {
    renderPersonRow(p);   // you already have this function
  });
}

async function loadPeopleWithFilters() {
  const gender = document.getElementById("filter_gender").value;
  const minAge = document.getElementById("filter_min_age").value;
  const maxAge = document.getElementById("filter_max_age").value;
  const education = document.getElementById("filter_education").value;

  let query = supabase
    .schema("cabo")
    .from("mm_people")
    .select("*")
    .order("last_name", { ascending: true });

  if (gender) query = query.eq("gender", gender);
  if (education) query = query.eq("education", education);
  if (minAge) query = query.gte("age", Number(minAge));
  if (maxAge) query = query.lte("age", Number(maxAge));

  const { data, error } = await query;

  if (error) {
    console.error(error);
    return;
  }

  renderPeopleList(data);
}


initMatchmaker();