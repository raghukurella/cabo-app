import { supabase } from "./supabase.js";

function getPersonIdFromHash() {
  const hash = window.location.hash; // e.g. "#/profile/12345"
  const parts = hash.split("/");
  return parts[2] || null;
}

async function loadProfile() {
  const personId = getPersonIdFromHash();
  const container = document.getElementById("profileViewContent");

  if (!personId) {
    container.innerHTML = '<div class="text-red-600">Invalid profile URL.</div>';
    return;
  }

  container.innerHTML = '<div class="text-sm text-gray-500">Loading...</div>';

  const { data, error } = await supabase
    .schema("cabo")
    .from("mm_people")
    .select("*")
    .eq("id", personId)
    .maybeSingle();

  if (error || !data) {
    container.innerHTML = '<div class="text-red-600">Profile not found.</div>';
    return;
  }

  renderProfile(data);
}

function renderProfile(p) {
  const container = document.getElementById("profileViewContent");

  const name = `${p.first_name ?? ""} ${p.last_name ?? ""}`.trim();

  container.innerHTML = `
    <div class="space-y-3">
      <h2 class="text-xl font-semibold">${name || "(No name)"}</h2>

      <p class="text-sm"><strong>Email:</strong> ${p.email || "N/A"}</p>
      <p class="text-sm"><strong>Phone:</strong> ${p.phone || "N/A"}</p>
      <p class="text-sm"><strong>Gender:</strong> ${p.gender || "N/A"}</p>
      <p class="text-sm"><strong>Age:</strong> ${p.age || "N/A"}</p>
      <p class="text-sm"><strong>Education:</strong> ${p.education || "N/A"}</p>

      <div class="pt-4">
        <h3 class="text-lg font-semibold">Bio</h3>
        <p class="text-sm">${p.bio || "No bio available."}</p>
      </div>
    </div>
  `;
}

loadProfile();  