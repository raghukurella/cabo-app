const { createClient } = supabase;

const supabaseClient = createClient(
  'https://tshowljfunfshsodwgtf.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg'
);


console.log('Supabase client:', supabaseClient);



let steps = [];
let currentStep = 0;

function renderStep() {
    const allSteps = document.querySelectorAll('.step'); // selects all inputs you've added
    allSteps.forEach((el, index) => {
      el.classList.toggle('hidden', index !== currentStep); // show current, hide others
    });
  
    document.getElementById('prevBtn').disabled = currentStep === 0;
    document.getElementById('nextBtn').textContent =
      currentStep === steps.length - 1 ? 'Submit' : 'Next';
}

function buildInput(labelText, name, type = 'text', options = null) {
  const div = document.createElement('div');
  div.className = 'form-field';

  const label = document.createElement('label');
  label.textContent = labelText;
  label.setAttribute('for', name);

  let input;
  if (type === 'select') {
    input = document.createElement('select');
    input.name = name;
    input.id = name;
    options.forEach(opt => {
      const option = document.createElement('option');
      option.value = opt;
      option.textContent = opt;
      input.appendChild(option);
    });
  } else if (type === 'checkbox') {
    input = document.createElement('input');
    input.type = 'checkbox';
    input.name = name;
    input.id = name;
  } else {
    input = document.createElement('input');
    input.type = type;
    input.name = name;
    input.id = name;
  }

  div.appendChild(label);
  div.appendChild(input);
  return div;
}

function loadSteps() {
    const container = document.getElementById('questionStep');
    steps = [
      buildInput('First Name', 'first_name'),
      buildInput('Last Name', 'last_name'),
      buildInput('Email', 'email', 'email'),
      buildInput('Phone Number', 'phone_number', 'tel'),
      buildInput('Age', 'age', 'number'),
      buildInput('Gender', 'gender'),
      buildInput('Location', 'location')
    ];
  
    // Load education levels
    supabaseClient
      .from('education_levels')
      .select('value')
      .then(({ data }) => {
        const eduOptions = data.map(d => d.value);
        steps.push(buildInput('Education Level', 'education', 'select', eduOptions));
  
        // Load questions
        return supabaseClient.from('questions').select('id, question_text');
      })
      .then(({ data }) => {
        data.forEach(q => {
          steps.push(buildInput(q.question_text, `question_${q.id}`, 'checkbox'));
        });
  
        // Append all steps to the DOM
        steps.forEach((step, index) => {
          step.classList.add('step');
          if (index !== 0) step.classList.add('hidden');
          container.appendChild(step);
        });
  
        renderStep();
      });
}

async function submitForm() {
  const form = document.getElementById('matchForm');
  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());

  const { data: demoData, error: demoError } = await supabaseClient
    .from('demographics')
    .insert([{
      first_name: data.first_name,
      last_name: data.last_name,
      email: data.email,
      phone_number: data.phone_number,
      age: parseInt(data.age),
      gender: data.gender,
      location: data.location,
      education: data.education
    }])
    .select();

  if (demoError) {
    console.error('Demographic insert error:', demoError);
    alert('Failed to submit demographic info.');
    return;
  }

  const demographic_id = demoData[0].id;

  const responses = [];
  for (let [key, value] of formData.entries()) {
    if (key.startsWith('question_')) {
      responses.push({
        demographic_id,
        question_id: parseInt(key.split('_')[1]),
        answer: true
      });
    }
  }

  const { error: responseError } = await supabaseClient
    .from('responses')
    .insert(responses);

  if (responseError) {
    console.error('Response insert error:', responseError);
    alert('Failed to submit responses.');
    return;
  }

  alert('Form submitted successfully!');
  form.reset();
  currentStep = 0;
  renderStep();
}

document.addEventListener('DOMContentLoaded', () => {
  loadSteps();

  document.getElementById('nextBtn').addEventListener('click', () => {
    if (currentStep === steps.length - 1) {
      submitForm();
    } else {
      currentStep++;
      renderStep();
    }
  });

  document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentStep > 0) {
      currentStep--;
      renderStep();
    }
  });
});