import { supabase } from "./data/supabase.js";

// ✅ Get person_id from URL (e.g., optional.html?person_id=123)
const urlParams = new URLSearchParams(window.location.search);
const personId = urlParams.get("person_id");

if (!personId) {
  alert("Missing person ID. Please go back and save required details first.");
  throw new Error("Missing person_id");
}

const questionsContainer = document.getElementById("questionsContainer");
const optionalForm = document.getElementById("optionalForm");
const skipBtn = document.getElementById("skipBtn");

// ✅ 1. Fetch active optional questions
async function loadQuestions() {
  const { data, error } = await supabase
    .from("mm_optional_questions")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("Error loading questions:", error);
    return;
  }

  // ✅ Render each question dynamically
  data.forEach((q) => {
    const wrapper = document.createElement("div");
    wrapper.className = "form-group";

    wrapper.innerHTML = `
      <label>${q.question_text}</label>
      <input 
        type="text" 
        data-question-id="${q.id}" 
        placeholder="Enter ${q.question_text}..."
      >
    `;

    questionsContainer.appendChild(wrapper);
  });
}

// ✅ 2. Save answers
async function saveAnswers(event) {
  event.preventDefault();

  const inputs = questionsContainer.querySelectorAll("input[data-question-id]");
  const answers = [];

  inputs.forEach((input) => {
    const value = input.value.trim();
    if (value !== "") {
      answers.push({
        person_id: personId,
        question_id: input.dataset.questionId,
        answer_text: value,
      });
    }
  });

  if (answers.length > 0) {
    const { error } = await supabase
      .from("mm_optional_answers")
      .insert(answers);

    if (error) {
      console.error("Error saving answers:", error);
      alert("There was an error saving your answers.");
      return;
    }
  }

  // ✅ Redirect or show success
  alert("Optional details saved.");
  window.location.href = "people.html";
}

// ✅ 3. Skip button
skipBtn.addEventListener("click", () => {
  window.location.href = "people.html";
});

// ✅ Load questions on page load
loadQuestions();

// ✅ Handle form submit
optionalForm.addEventListener("submit", saveAnswers);