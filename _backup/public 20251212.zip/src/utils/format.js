export function calculateAge(dateString) {
  if (!dateString) return '';
  const dob = new Date(dateString);
  const diff = Date.now() - dob.getTime();
  const age = new Date(diff).getUTCFullYear() - 1970;
  return age;
}

export function formatHeight(feet, inches) {
  if (!feet) return '';
  return inches ? `${feet}' ${inches}"` : `${feet}'`;
}