// validation.js

// ✅ Email validation
export function isValidEmail(email) {
  if (!email) return false;
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// ✅ Phone number validation (basic US format, extend as needed)
export function isValidPhone(phone) {
  if (!phone) return false;
  const regex = /^\+?[0-9]{7,15}$/; // allows optional +, 7–15 digits
  return regex.test(phone);
}

// ✅ Zip code validation (US 5-digit or ZIP+4)
export function isValidZip(zip) {
  if (!zip) return false;
  const regex = /^\d{5}(-\d{4})?$/;
  return regex.test(zip);
}

// ✅ Date validation (YYYY-MM-DD)
export function isValidDate(dateStr) {
  if (!dateStr) return false;
  const regex = /^\d{4}-\d{2}-\d{2}$/;
  return regex.test(dateStr);
}

// ✅ Time validation (HH:MM, 24-hour)
export function isValidTime(timeStr) {
  if (!timeStr) return false;
  const regex = /^([01]\d|2[0-3]):([0-5]\d)$/;
  return regex.test(timeStr);
}

// ✅ Height validation (feet and inches must be numbers)
export function isValidHeight(feet, inches) {
  if (feet == null) return false;
  const f = parseInt(feet, 10);
  const i = inches ? parseInt(inches, 10) : 0;
  return Number.isInteger(f) && f > 0 && Number.isInteger(i) && i >= 0 && i < 12;
}
export function isValidHeightFeet(value) {
  const num = Number(value);
  return !isNaN(num) && num >= 3 && num <= 8;
}

export function isValidHeightInches(value) {
  const num = Number(value);
  return !isNaN(num) && num >= 0 && num <= 11;
}







// utils/validation.js

// A simple list of accepted gothrams for your project.
// You can expand this list as needed.
const allowedGothrams = [
  "Kashyapa",
  "Bharadwaja",
  "Vasishta",
  "Gautama",
  "Atri",
  "Agastya",
  "Viswamitra",
  "Jamadagni"
];

// Named export so you can import { isValidGothram }
export function isValidGothram(value) {
  if (!value || typeof value !== "string") return false;

  const normalized = value.trim().toLowerCase();
  return allowedGothrams.some(g => g.toLowerCase() === normalized);
}

export function  isValidNakshatram(value) { return value}
export function  isValidRaasi(value) { return value}
export function  isValidLagnam (value) { return value}
