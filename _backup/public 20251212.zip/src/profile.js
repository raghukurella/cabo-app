import { supabase } from "./data/supabase.js";

const urlParams = new URLSearchParams(window.location.search);
const personId = urlParams.get("person_id");

if (!personId) {
  alert("Missing person ID.");
  throw new Error("Missing person_id");
}

const profileForm = document.getElementById("profileForm");
const optionalContainer = document.getElementById("optionalContainer");

// ✅ Load required fields
async function loadRequired() {
  const { data, error } = await supabase
    .from("mm_people")
    .select("*")
    .eq("id", personId)
    .single();

  if (error) {
    console.error(error);
    return;
  }

  document.getElementById("firstName").value = data.first_name || "";
  document.getElementById("lastName").value = data.last_name || "";
  document.getElementById("email").value = data.email || "";
  document.getElementById("phone").value = data.phone_number || "";
  document.getElementById("dobtob").value = data.datetime_of_birth || "";
  document.getElementById("placeOfBirth").value = data.place_of_birth || "";
  document.getElementById("heightFeet").value = data.height_feet || "";
  document.getElementById("heightInches").value = data.height_inches || "";
}

// ✅ Load optional questions + answers
async function loadOptional() {
  const { data: questions } = await supabase
    .from("mm_optional_questions")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  const { data: answers } = await supabase
    .from("mm_optional_answers")
    .select("*")
    .eq("person_id", personId);

  const answerMap = {};
  answers?.forEach(a => answerMap[a.question_id] = a.answer_text);

  questions.forEach(q => {
    const wrapper = document.createElement("div");
    wrapper.className = "form-group";

    wrapper.innerHTML = `
      <label>${q.question_text}</label>
      <input 
        type="text" 
        data-question-id="${q.id}"
        value="${answerMap[q.id] || ""}"
      >
    `;

    optionalContainer.appendChild(wrapper);
  });
}

// ✅ Save updates
profileForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  // ✅ Update required fields
  const updates = {
    first_name: document.getElementById("firstName").value.trim(),
    last_name: document.getElementById("lastName").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone_number: document.getElementById("phone").value.trim(),
    datetime_of_birth: document.getElementById("dobtob").value || null,
    place_of_birth: document.getElementById("placeOfBirth").value.trim(),
    height_feet: Number(document.getElementById("heightFeet").value) || null,
    height_inches: Number(document.getElementById("heightInches").value) || null
  };

  await supabase
    .from("mm_people")
    .update(updates)
    .eq("id", personId);

  // ✅ Update optional answers
  const inputs = optionalContainer.querySelectorAll("input[data-question-id]");
  const upserts = [];

  inputs.forEach(input => {
    upserts.push({
      person_id: personId,
      question_id: input.dataset.questionId,
      answer_text: input.value.trim()
    });
  });

  await supabase
    .from("mm_optional_answers")
    .upsert(upserts);

  alert("Profile updated.");
});

// ✅ Load everything
loadRequired();
loadOptional();