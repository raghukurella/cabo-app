import { supabase } from './data/supabase.js';

document.getElementById('signupForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = e.target.email.value.trim();
  const password = e.target.password.value.trim();

  const { data, error } = await supabase.auth.signUp({ email:email, password:password });
  console.log(data, error);

//  const { data, error } = await supabase.auth.signUp({ email, password });

  if (error) {
    alert('Signup failed: ' + error.message);
    console.error(error); // log full error object
    return;
  }

  const user = data.user;
  if (!user) {
    alert('Signup sssss incomplete — check your email for confirmation.');
    return;
  }

  // Insert profile with default role
  const { error: profileError } = await supabase
    .from('mm_profiles')
    .insert([{ id: user.id, role: 'member' }]);

  if (profileError) {
    alert('Error creating profile: ' + profileError.message);
    console.error(profileError);
    return;
  }

  alert('Account created successfully! Please check your email to confirm.');
  window.location.href = 'login.html';
});