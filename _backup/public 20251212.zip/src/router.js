import { supabase } from "./data/supabase.js";

async function routeAfterLogin() {
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) return;

  // ✅ Admin check
  if (user.user_metadata?.role === "admin") {
    window.location.href = "people.html";
    return;
  }

  // ✅ Check if profile exists
  const { data: person, error } = await supabase
    .from("mm_people")
    .select("id")
    .eq("auth_user_id", user.id)
    .maybeSingle();   // ✅ IMPORTANT: prevents errors when no row exists

  if (!person) {
    // ✅ First-time user
    window.location.href = "addnew.html";
  } else {
    // ✅ Returning user
    window.location.href = `profile.html?person_id=${person.id}`;
  }
}

routeAfterLogin();