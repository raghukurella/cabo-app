import { supabase } from './data/supabase.js';

document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = e.target.email.value;
  const password = e.target.password.value;

  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password
  });

  if (error) {
    alert('Login failed: ' + error.message);
    return;
  }

  // ✅ Get user role from Supabase profile table
  const { data: profile } = await supabase
    .from('mm_profiles')
    .select('role')
    .eq('id', data.user.id)
    .single();

  if (!profile) {
    alert('No role assigned. Contact admin.');
    return;
  }

  // Redirect based on role
  switch (profile.role) {
    case 'app_admin':
      window.location.href = 'adminDashboard.html';
      break;
    case 'data_editor':
      window.location.href = 'people.html';
      break;
    case 'data_reviewer':
      window.location.href = 'reviewerDashboard.html';
      break;
    case 'member':
      window.location.href = 'addNew.html';
      break;
    default:
      alert('Unknown role');
  }
  
});