// public/src/js/test.js
import { supabase, testConnection } from "../data/supabase.js";

const output = document.getElementById("output");

function log(label, value) {
  output.textContent += `\n${label}: ${JSON.stringify(value, null, 2)}\n`;
}

document.getElementById("btnTest").addEventListener("click", async () => {
  output.textContent = "Running Supabase connectivity test...\n";

  // ✅ Test auth
  const { data: authData, error: authError } = await supabase.auth.getSession();
  log("Auth Session", authData || authError);

  // ✅ Test DB
  const { data, error } = await testConnection();
  log("DB Test", data || error);
});