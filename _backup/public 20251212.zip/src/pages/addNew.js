// addNew.js
import {
  isValidEmail, isValidPhone, isValidZip, isValidDate, isValidTime,
  isValidHeightFeet, isValidHeightInches,
  isValidNakshatram, isValidRaasi, isValidLagnam, isValidGothram
} from '../utils/validation.js';
import { supabase } from '../data/supabase.js';

export function initAddNewPage() {
  const form = document.getElementById('addForm');
  if (!form) return; // only run on addNew.html

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const user = {
      first_name: form.first_name.value.trim(),
      last_name: form.last_name.value.trim(),
      email: form.email.value.trim(),
      phone_number: form.phone_number.value.trim(),
      date_of_birth: form.date_of_birth.value,
      time_of_birth: form.time_of_birth.value,
      place_of_birth: form.place_of_birth.value.trim(),
      zip: form.zip.value.trim(),
      education: form.education.value.trim(),
      height_feet: form.height_feet.value.trim(),
      height_inches: form.height_inches.value.trim(),
      nakshatram: form.nakshatram.value.trim(),
      raasi: form.raasi.value.trim(),
      lagnam: form.lagnam.value.trim(),
      gothram: form.gothram.value.trim()
    };

    // ✅ Validation
    if (!isValidEmail(user.email)) {
      alert('Invalid email address');
      return;
    }
    if (user.phone_number && !isValidPhone(user.phone_number)) {
      alert('Invalid phone number');
      return;
    }
    if (user.zip && !isValidZip(user.zip)) {
      alert('Invalid ZIP code');
      return;
    }
    if (user.date_of_birth && !isValidDate(user.date_of_birth)) {
      alert('Invalid date of birth');
      return;
    }
    if (user.time_of_birth && !isValidTime(user.time_of_birth)) {
      alert('Invalid time of birth');
      return;
    }
    if (user.height_feet && !isValidHeightFeet(user.height_feet)) {
      alert('Height (feet) must be between 3 and 8');
      return;
    }
    if (user.height_inches && !isValidHeightInches(user.height_inches)) {
      alert('Height (inches) must be between 0 and 11');
      return;
    }
    if (user.nakshatram && !isValidNakshatram(user.nakshatram)) {
      alert('Invalid Nakshatram');
      return;
    }
    if (user.raasi && !isValidRaasi(user.raasi)) {
      alert('Invalid Raasi');
      return;
    }
    if (user.lagnam && !isValidLagnam(user.lagnam)) {
      alert('Invalid Lagnam');
      return;
    }
    if (user.gothram && !isValidGothram(user.gothram)) {
      alert('Invalid Gothram');
      return;
    }


  //---------------------------------------



 const gothram = e.target.gothram.value.trim();

  if (!isValidGothram(gothram)) {
    alert("Invalid Gothram. Please enter a valid one.");
    return;
  }


  //---------------------------------------






    // ✅ Insert into mm_people
    const { data: authUser } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from('mm_people')
      .insert([{ ...user, user_id: authUser.user.id }]);

    if (error) {
      console.error(error);
      alert('Error saving record: ' + error.message);
    } else {
      alert('Record saved successfully!');
      form.reset();
    }
  });


  const files = document.getElementById("photos").files;

if (files.length > 5) {
  alert("Please upload no more than 5 photos.");
  return;
}

}