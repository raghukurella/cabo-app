// people.js
import { supabase } from '../data/supabase.js';
import { renderGrid } from '../ui/renderGrid.js';
import { renderDetails } from '../ui/renderDetails.js';

export function initPeoplePage() {
  const table = document.getElementById('peopleTable');
  if (!table) return; // only run on people.html

  async function loadPeople() {
    const { data, error } = await supabase
      .from('mm_people')
      .select('*')
      .is('deleted_at', null); // ✅ only active records

    if (error) {
      console.error(error);
      alert('Error loading people: ' + error.message);
      return;
    }

    renderGrid(data, showDetails, softDeletePerson);
  }

  function showDetails(person) {
    const existing = document.querySelector('.details-row');
    if (existing) existing.remove();

    const detailsRow = document.createElement('tr');
    detailsRow.className = 'details-row';

    const detailsCell = document.createElement('td');
    detailsCell.colSpan = 4;
    detailsCell.appendChild(renderDetails(person, softDeletePerson));

    detailsRow.appendChild(detailsCell);

    const rows = Array.from(table.querySelectorAll('tr'));
    const targetRow = rows.find(r => r.cells[0]?.textContent.includes(person.first_name));
    if (targetRow) {
      targetRow.insertAdjacentElement('afterend', detailsRow);
    }
  }

  async function softDeletePerson(person) {
    const { data: authUser } = await supabase.auth.getUser();

    const { error } = await supabase
      .from('mm_people')
      .update({
        deleted_at: new Date().toISOString(),
        deleted_by: authUser.user.id
      })
      .eq('id', person.id);

    if (error) {
      console.error(error);
      alert('Error removing person: ' + error.message);
    } else {
      alert('Person removed successfully (soft delete)');
      loadPeople();
    }
  }

  loadPeople();
}