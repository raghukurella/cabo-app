// renderGrid.js
import { supabase } from '../data/supabase.js';

export async function renderGrid(data, onDetailsClick, onRemoveClick) {
  const table = document.getElementById('peopleTable');
  table.innerHTML = '';

  // ✅ Get current user + role
  const { data: { user } } = await supabase.auth.getUser();
  let role = null;
  if (user) {
    const { data: profile } = await supabase
      .from('mm_profiles')
      .select('role')
      .eq('id', user.id)
      .single();
    role = profile?.role;
  }

  // Header row
  const header = document.createElement('tr');
  header.innerHTML = `
    <th>Name</th>
    <th>Email</th>
    <th>Phone</th>
    <th>Actions</th>
  `;
  table.appendChild(header);

  // Data rows
  data.forEach(person => {
    const row = document.createElement('tr');

    row.innerHTML = `
      <td>${person.first_name} ${person.last_name}</td>
      <td>${person.email || ''}</td>
      <td>${person.phone_number || ''}</td>
      <td></td>
    `;

    // Details button (always visible)
    const detailsBtn = document.createElement('button');
    detailsBtn.textContent = '☰';
    detailsBtn.className = 'btn btn-neutral';
    detailsBtn.addEventListener('click', () => onDetailsClick(person));

    const actionsCell = row.querySelector('td:last-child');
    actionsCell.appendChild(detailsBtn);

    // ✅ Role-aware Remove button
    const canRemove =
      role === 'app_admin' ||
      role === 'data_editor' ||
      (role === 'member' && person.user_id === user.id);

    if (canRemove) {
      const removeBtn = document.createElement('button');
      removeBtn.textContent = '🗑️ Remove';
      removeBtn.className = 'btn btn-danger';
      removeBtn.addEventListener('click', () => onRemoveClick(person));
      actionsCell.appendChild(removeBtn);
    }

    table.appendChild(row);
  });
}