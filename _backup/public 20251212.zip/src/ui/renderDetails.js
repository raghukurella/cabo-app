// renderDetails.js
import { supabase } from '../data/supabase.js';

export async function renderDetails(person, onRemoveClick) {
  const detailsTable = document.createElement('table');
  detailsTable.className = 'details-table';

  // ✅ Get current user role
  const { data: { user } } = await supabase.auth.getUser();
  let role = null;
  if (user) {
    const { data: profile } = await supabase
      .from('mm_profiles')
      .select('role')
      .eq('id', user.id)
      .single();
    role = profile?.role;
  }

  const fields = [
    ['First Name', person.first_name],
    ['Last Name', person.last_name],
    ['Email', person.email],
    ['Phone', person.phone_number],
    ['Date of Birth', person.date_of_birth],
    ['Time of Birth', person.time_of_birth],
    ['Place of Birth', person.place_of_birth],
    ['Zip', person.zip],
    ['Education', person.education],
    ['Height', person.height_feet && person.height_inches 
        ? `${person.height_feet} ft ${person.height_inches} in` 
        : ''],
    ['Nakshatram', person.nakshatram],
    ['Raasi', person.raasi],
    ['Lagnam', person.lagnam],
    ['Gothram', person.gothram]
  ];

  // ✅ Show deleted info only for admins/editors
  if ((role === 'app_admin' || role === 'data_editor') && person.deleted_at) {
    fields.push(['Deleted At', person.deleted_at]);
    fields.push(['Deleted By', person.deleted_by]);
  }

  fields.forEach(([label, value]) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${label}</td>
      <td>${value || ''}</td>
    `;
    detailsTable.appendChild(row);
  });

  // ✅ Remove button only for roles allowed to delete
  if (role === 'app_admin' || role === 'data_editor' || role === 'member') {
    const removeBtn = document.createElement('button');
    removeBtn.textContent = '🗑️ Remove';
    removeBtn.className = 'btn btn-danger removeBtn';
    removeBtn.addEventListener('click', () => onRemoveClick(person));

    const actionRow = document.createElement('tr');
    const actionCell = document.createElement('td');
    actionCell.colSpan = 2;
    actionCell.appendChild(removeBtn);
    actionRow.appendChild(actionCell);
    detailsTable.appendChild(actionRow);
  }

  return detailsTable;
}