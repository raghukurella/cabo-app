
// src/data/supabase.js
import { createClient } from "https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm";


const SUPABASE_URL = 'https://tshowljfunfshsodwgtf.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);





console.log(SUPABASE_URL, SUPABASE_ANON_KEY);

const { data, error } = await supabase.from('mm_people').select('*').limit(1);
console.log(data, error);






// Example query functions
export async function fetchDemographics(limit = 2000) {
  return await supabase
    .from('demographics')
    .select('*')
    .limit(limit);
}

export async function fetchUnifiedResults(limit = 2000) {
  return await supabase
    .from('unified_results')
    .select('*')
    .limit(limit);
}

export async function updateResponse(demographicId, question, newResponse) {
  return await supabase
    .from('unified_results')
    .update({ response: newResponse })
    .eq('demographic_id', demographicId)
    .eq('question', question);
}
