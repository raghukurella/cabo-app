import { fetchDemographics } from './supabase.js';

export async function hydrateResults(usersById) {
  const { data: demographics, error } = await fetchDemographics();
  if (error) throw error;

  const demographicIds = new Set(Object.keys(usersById));

  demographics.forEach(demo => {
    if (demographicIds.has(demo.id)) {
      const user = usersById[demo.id];
      Object.assign(user, {
        phone_number: demo.phone_number || '',
        zip: demo.zip || '',
        date_of_birth: demo.date_of_birth || '',
        time_of_birth: demo.time_of_birth || '',
        place_of_birth: demo.place_of_birth || '',
        height_feet: demo.height_feet || '',
        height_inches: demo.height_inches || '',
        country_of_citizenship: demo.country_of_citizenship || '',
        citizenship_at_birth: demo.citizenship_at_birth || '',
        highest_degree: demo.highest_degree || '',
        secondary_education: demo.secondary_education || '',
        secondary_degree: demo.secondary_degree || '',
        education_notes: demo.education_notes || '',
        previously_married: demo.previously_married || false,
        nakshatram: demo.nakshatram || '',
        raasi: demo.raasi || '',
        lagnam: demo.lagnam || '',
        gothram: demo.gothram || '',
        education: demo.highest_education_level || '',
        email: user.email || demo.email || ''
      });
    }
  });

  return usersById;
}