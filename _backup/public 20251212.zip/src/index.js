import { supabase } from "./data/supabase.js";

console.log("✅ index.js loaded");

const form = document.getElementById("addForm");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  console.log("✅ Form submitted");

  // ✅ Get the logged-in user
  const { data: { user } } = await supabase.auth.getUser();
  console.log("✅ Logged-in user:", user);

  // ✅ Collect required fields
  const personData = {
    auth_user_id: user.id,   // ✅ THIS IS THE IMPORTANT LINE
    first_name: document.getElementById("firstName").value.trim(),
    last_name: document.getElementById("lastName").value.trim(),
    email: document.getElementById("email").value.trim(),
    phone_number: document.getElementById("phone").value.trim(),
    datetime_of_birth: document.getElementById("dobtob").value || null,
    place_of_birth: document.getElementById("placeOfBirth").value.trim(),
    height_feet: Number(document.getElementById("heightFeet").value) || null,
    height_inches: Number(document.getElementById("heightInches").value) || null
  };

  console.log("✅ Data to insert:", personData);

  // ✅ Insert into mm_people
  const { data, error } = await supabase
    .from("mm_people")
    .insert([personData])
    .select("id")
    .single();

  console.log("✅ Insert result:", { data, error });

  if (error) {
    alert("Insert failed. Check console.");
    return;
  }

  // ✅ Redirect to optional questions
  window.location.href = `optional.html?person_id=${data.id}`;
});