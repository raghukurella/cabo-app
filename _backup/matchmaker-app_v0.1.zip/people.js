const { createClient } = supabase;

const supabaseClient = createClient(
  'https://tshowljfunfshsodwgtf.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg'
);

async function loadResults() {
  const { data, error } = await supabaseClient
    .from('matchmaker_results')
    .select('*');

  if (error) {
    console.error('Results error:', error);
    return;
  }

  const container = document.getElementById('resultsContainer');
  container.innerHTML = '';

  const questions = [...new Set(data.map(row => row.question_text))];

  const users = {};
  data.forEach(row => {
    const key = row.demographic_id;
    if (!users[key]) {
      users[key] = {
        name: `${row.first_name} ${row.last_name}`,
        email: row.email,
        responses: {}
      };
    }
    users[key].responses[row.question_text] = row.answer ? 'Yes' : 'No';
  });

  const table = document.createElement('table');

  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');
  headerRow.innerHTML = `<th>Name</th>`;
  questions.forEach(q => {
    const th = document.createElement('th');
    th.textContent = q;
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  Object.values(users).forEach(user => {
    const row = document.createElement('tr');
    row.innerHTML = `<td>${user.name}</td>`;
    questions.forEach(q => {
      const answer = user.responses[q] || '';
      const td = document.createElement('td');
      td.textContent = answer;
      row.appendChild(td);
    });
    tbody.appendChild(row);
  });

  table.appendChild(tbody);
  container.appendChild(table);
}

document.addEventListener('DOMContentLoaded', loadResults);