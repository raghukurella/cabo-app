const { createClient } = supabase;

const supabaseClient = supabase.createClient(
    'https://tshowljfunfshsodwgtf.supabase.co',
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg'
  );
  

  supabaseClient.auth.getSession().then(({ data, error }) => {
    if (error) {
      console.error('Supabase connection failed:', error);
    } else {
      console.log('Supabase connected successfully');
    }
  });
  
  
  
  
  // Load education levels
  async function loadEducationDropdown() {
    const { data, error } = await supabaseClient
      .from('education_levels')
      .select('value');
  
    if (error) return console.error('Dropdown error:', error);
  
    const dropdown = document.getElementById('educationDropdown');
    data.forEach(({ value }) => {
      const option = document.createElement('option');
      option.value = value;
      option.textContent = value;
      dropdown.appendChild(option);
    });
  }
  
  // Load questions
  async function loadQuestions() {
    const { data, error } = await supabaseClient
      .from('questions')
      .select('id, question_text');
  
    if (error) return console.error('Questions error:', error);
  
    const container = document.getElementById('questionsContainer');
    data.forEach(({ id, question_text }) => {
      const label = document.createElement('label');
      label.innerHTML = `
        <input type="checkbox" name="question_${id}" />
        ${question_text}
      `;
      container.appendChild(label);
    });
  }

  async function loadResults() {
    const { data, error } = await supabaseClient
      .from('matchmaker_results')
      .select('*');
  
    if (error) {
      console.error('Results error:', error);
      return;
    }
  
    const container = document.getElementById('resultsContainer');
    container.innerHTML = '';
  
    // 🔹 Extract unique questions
    const questions = [...new Set(data.map(row => row.question_text))];
  
    // 🔹 Group responses by user
    const users = {};
    data.forEach(row => {
      const key = row.demographic_id;
      if (!users[key]) {
        users[key] = {
          name: `${row.first_name} ${row.last_name}`,
          email: row.email,
          responses: {}
        };
      }
      users[key].responses[row.question_text] = row.answer ? 'Yes' : 'No';
    });
  
    // 🔹 Build table
    const table = document.createElement('table');
    table.style.borderCollapse = 'collapse';
    table.style.marginBottom = '1em';
  
    // Header row
    const thead = document.createElement('thead');
    const headerRow = document.createElement('tr');
    headerRow.innerHTML = `<th style="border: 1px solid #ccc; padding: 6px;">Name</th>`;
    questions.forEach(q => {
      const th = document.createElement('th');
      th.textContent = q;
      th.style.border = '1px solid #ccc';
      th.style.padding = '6px';
      headerRow.appendChild(th);
    });
    thead.appendChild(headerRow);
    table.appendChild(thead);
  
    // Body rows
    const tbody = document.createElement('tbody');
    Object.values(users).forEach(user => {
      const row = document.createElement('tr');
      row.innerHTML = `<td style="border: 1px solid #ccc; padding: 6px;">${user.name}</td>`;
      questions.forEach(q => {
        const answer = user.responses[q] || '';
        const td = document.createElement('td');
        td.textContent = answer;
        td.style.border = '1px solid #ccc';
        td.style.padding = '6px';
        row.appendChild(td);
      });
      tbody.appendChild(row);
    });
  
    table.appendChild(tbody);
    container.appendChild(table);
  }
  
  // Initialize form
//  loadEducationDropdown();
//  loadQuestions();

  document.addEventListener('DOMContentLoaded', () => {
    loadEducationDropdown();
    loadQuestions();
    loadResults();
  
    const form = document.getElementById('matchForm');
    form.addEventListener('submit', submitForm);
  });





  async function submitForm(event) {
    event.preventDefault(); // prevent page reload
  
    const form = event.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
  
    // Insert into demographics
    const { data: demoData, error: demoError } = await supabaseClient
      .from('demographics')
      .insert([{
        first_name: data.first_name,
        last_name: data.last_name,
        email: data.email,
        phone_number: data.phone_number,
        age: parseInt(data.age),
        gender: data.gender,
        location: data.location,
        education: data.education
      }])
      .select();
  
    if (demoError) {
      console.error('Demographic insert error:', demoError);
      alert('Failed to submit demographic info.');
      return;
    }
  
    const demographic_id = demoData[0].id;
  
    // Insert responses
    const questionInputs = Array.from(document.querySelectorAll('[name^="question_"]'));
    const responses = questionInputs.map(input => ({
      demographic_id,
      question_id: parseInt(input.name.split('_')[1]),
      answer: input.checked
    }));
  
    const { error: responseError } = await supabaseClient
      .from('responses')
      .insert(responses);
  
    if (responseError) {
      console.error('Response insert error:', responseError);
      alert('Failed to submit responses.');
      return;
    }
  
    alert('Form submitted successfully!');
    form.reset();

    loadResults();

  }

  




  document.addEventListener('DOMContentLoaded', () => {
    loadEducationDropdown();
    loadQuestions();
  
    const form = document.getElementById('matchForm');
    form.addEventListener('submit', submitForm);
  });

