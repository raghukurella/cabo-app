const { createClient } = supabase;

// Initialize Supabase client
const supabaseClient = createClient(
  'https://tshowljfunfshsodwgtf.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg'
);

let currentPage = 0;
const pageSize = 10; // adjust for mobile-friendly pages
let currentFilters = {};
let allUsers = [];
let questions = [];
let searchTerm = "";

// --- Components ---

function renderHeader() {
  const thead = document.createElement('thead');
  const headerRow = document.createElement('tr');

  ['First Name','Last Name','Gender','Education','Actions'].forEach(label => {
    const th = document.createElement('th');
    th.textContent = label;
    headerRow.appendChild(th);
  });

  thead.appendChild(headerRow);
  return thead;
}

function renderRow(user, questions) {
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${user.first_name || ''}</td>
    <td>${user.last_name || ''}</td>
    <td>${user.gender || ''}</td>
    <td>${user.education || ''}</td>
    <td><button class="detailsBtn">View Details</button></td>
  `;

  // Hidden details row
  const detailsRow = document.createElement('tr');
  detailsRow.style.display = 'none';
  const detailsCell = document.createElement('td');
  detailsCell.colSpan = 5;

  // Build details content
  let detailsHTML = `
    <strong>Location:</strong> ${user.location || ''}<br>
    <strong>Email:</strong> ${user.email || ''}<br>
    <strong>Responses:</strong><br>
    <ul>
  `;
  questions.forEach(q => {
    detailsHTML += `<li>${q}: ${user.responses[q] || ''}</li>`;
  });
  detailsHTML += `</ul>
    <button class="removeBtn">🗑️ Remove</button>
  `;

  detailsCell.innerHTML = detailsHTML;
  detailsRow.appendChild(detailsCell);

  // Toggle details
  row.querySelector('.detailsBtn').addEventListener('click', () => {
    detailsRow.style.display = detailsRow.style.display === 'none' ? 'table-row' : 'none';
  });

  // Remove logic (inside details row)
  detailsRow.querySelector('.removeBtn').addEventListener('click', async () => {
    const confirmed = confirm(`Remove ${user.first_name || ''} ${user.last_name || ''}?`);
    if (!confirmed) return;

    if (!user.demographic_id) {
      console.error('Missing demographic_id for removal.');
      return;
    }

    const { error } = await supabaseClient
      .from('demographics')
      .update({
        deleted_date: new Date().toISOString(),
        deleted_by: 'system' // TODO: replace with logged-in user
      })
      .eq('id', user.demographic_id);

    if (error) {
      console.error('Error marking deleted:', error.message);
      return;
    }

    // Refresh results after deletion
    loadResults(currentPage, currentFilters);
  });

  return [row, detailsRow];
}

function renderBody(users, questions) {
  const tbody = document.createElement('tbody');
  users.forEach(user => {
    const [mainRow, detailsRow] = renderRow(user, questions);
    tbody.appendChild(mainRow);
    tbody.appendChild(detailsRow);
  });
  return tbody;
}

function renderPagination(currentPage, totalPages) {
  const pagination = document.getElementById('paginationControls');
  pagination.innerHTML = '';

  const prevBtn = document.createElement('button');
  prevBtn.textContent = 'Previous';
  prevBtn.disabled = currentPage <= 0 || totalPages <= 1;
  prevBtn.onclick = () => loadResults(currentPage - 1, currentFilters);

  const pageInfo = document.createElement('span');
  pageInfo.textContent = `Page ${currentPage + 1} of ${totalPages}`;
  pageInfo.className = 'page-info';

  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Next';
  nextBtn.disabled = currentPage >= totalPages - 1 || totalPages <= 1;
  nextBtn.onclick = () => loadResults(currentPage + 1, currentFilters);

  pagination.appendChild(prevBtn);
  pagination.appendChild(pageInfo);
  pagination.appendChild(nextBtn);
}

function renderTable(users, questions, totalUsers, totalPages) {
  const container = document.getElementById('resultsContainer');
  container.innerHTML = '';

  if (!users || users.length === 0) {
    container.innerHTML = '<p>No results found.</p>';
    renderPagination(0, 1);
    return;
  }

  const table = document.createElement('table');
  table.appendChild(renderHeader());
  table.appendChild(renderBody(users, questions));
  container.appendChild(table);

  renderPagination(currentPage, totalPages);
}

// --- Data Fetch + Pagination ---

async function loadResults(page = 0, filters = {}) {
  currentPage = page;
  currentFilters = filters;

  // Fetch enough rows from unified_results, exclude deleted
  const { data, error } = await supabaseClient
    .from('unified_results')
    .select('*')
    .is('deleted_date', null)
    .limit(2000); // adjust upper bound based on expected size

  if (error) {
    console.error('Unified results error:', error.message, error.details);
    return;
  }

  questions = [...new Set(data.map(r => r.question_text).filter(Boolean))];

  // Group rows into users (one per demographic_id)
  const usersById = {};
  data.forEach(row => {
    const key = row.demographic_id;
    if (!key) return;

    if (!usersById[key]) {
      usersById[key] = {
        demographic_id: row.demographic_id,
        first_name: row.first_name,
        last_name: row.last_name,
        email: row.email,
        gender: row.gender,
        location: row.location,
        education: row.education,
        responses: {}
      };
    }
    if (row.question_text) {
      usersById[key].responses[row.question_text] = row.answer ? 'Yes' : 'No';
    }
  });

  allUsers = Object.values(usersById);

  // Apply filters
  let filteredUsers = allUsers;
  if (filters.gender) {
    filteredUsers = filteredUsers.filter(
      u => (u.gender || '').toLowerCase() === filters.gender.toLowerCase()
    );
  }
  if (filters.location) {
    filteredUsers = filteredUsers.filter(
      u => (u.location || '').toLowerCase().includes(filters.location.toLowerCase())
    );
  }
  if (filters.education) {
    filteredUsers = filteredUsers.filter(u => u.education === filters.education);
  }

  // Apply search
  if (searchTerm) {
    const term = searchTerm.toLowerCase();
    filteredUsers = filteredUsers.filter(u =>
      (u.first_name || '').toLowerCase().includes(term) ||
      (u.last_name || '').toLowerCase().includes(term) ||
      (u.education || '').toLowerCase().includes(term)
    );
  }

  // Paginate users (after grouping)
  const totalUsers = filteredUsers.length;
  if (totalUsers === 0) {
    renderTable([], questions, 0, 1);
    return;
  }

  const totalPages = Math.max(1, Math.ceil(totalUsers / pageSize));
  const start = page * pageSize;
  const end = start + pageSize;
  const pageUsers = filteredUsers.slice(start, end);

  renderTable(pageUsers, questions, totalUsers, totalPages);
}

// --- Event Listeners ---

document.addEventListener('DOMContentLoaded', () => {
  populateFilters();   // fetch filter options dynamically
  loadResults();

  document.getElementById('applyFilters').addEventListener('click', () => {
    const filters = {
      gender: document.getElementById('filterGender').value,
      location: document.getElementById('filterLocation').value,
      education: document.getElementById('filterEducation').value
    };
    loadResults(0, filters);
  });

  document.getElementById('resetFilters').addEventListener('click', () => {
    document.getElementById('filterGender').value = '';
    document.getElementById('filterLocation').value = '';
    document.getElementById('filterEducation').value = '';
    searchTerm = '';
    document.getElementById('searchInput').value = '';
    loadResults(0, {}); // reload all users
  });

  document.getElementById('searchButton').addEventListener('click', () => {
    searchTerm = document.getElementById('searchInput').value;
    loadResults(0, currentFilters);
  });
});

// --- Filters (dynamic from DB, excluding deleted) ---

async function populateFilters() {
    // Clear existing options (keep the empty/default option if present)
    const genderSelect = document.getElementById('filterGender');
    const locationSelect = document.getElementById('filterLocation');
    const educationSelect = document.getElementById('filterEducation');
  
    if (!genderSelect || !locationSelect || !educationSelect) {
      console.error('Filter elements not found. Ensure filterGender, filterLocation, filterEducation exist in HTML.');
      return;
    }
  
    // Remove all existing options
    genderSelect.innerHTML = '<option value="">All</option>';
    locationSelect.innerHTML = '<option value="">All</option>';
    educationSelect.innerHTML = '<option value="">All</option>';
  
    // Run independent queries (do NOT reuse a "base" query)
    const genderPromise = supabaseClient
      .from('demographics')
      .select('gender')
      .is('deleted_date', null)
      .not('gender', 'is', null);
  
    const locationPromise = supabaseClient
      .from('demographics')
      .select('location')
      .is('deleted_date', null)
      .not('location', 'is', null);
  
    const educationPromise = supabaseClient
      .from('demographics')
      .select('education')
      .is('deleted_date', null)
      .not('education', 'is', null);
  
    const [
      { data: genders, error: gError },
      { data: locations, error: lError },
      { data: educations, error: eError }
    ] = await Promise.all([genderPromise, locationPromise, educationPromise]);
  
    if (gError || lError || eError) {
      console.error('Filter fetch error:', gError || lError || eError);
      return;
    }
  
    // Deduplicate, sanitize, sort
    const uniqueGenders = [...new Set((genders || []).map(g => (g.gender || '').trim()))]
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b));
  
    const uniqueLocations = [...new Set((locations || []).map(l => (l.location || '').trim()))]
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b));
  
    const uniqueEducations = [...new Set((educations || []).map(e => (e.education || '').trim()))]
      .filter(Boolean)
      .sort((a, b) => a.localeCompare(b));
  
    // Populate dropdowns
    uniqueGenders.forEach(val => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = val;
      genderSelect.appendChild(opt);
    });
  
    uniqueLocations.forEach(val => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = val;
      locationSelect.appendChild(opt);
    });
  
    uniqueEducations.forEach(val => {
      const opt = document.createElement('option');
      opt.value = val;
      opt.textContent = val;
      educationSelect.appendChild(opt);
    });
  
    console.log('Filters populated:',
      { genders: uniqueGenders.length, locations: uniqueLocations.length, educations: uniqueEducations.length });
  }