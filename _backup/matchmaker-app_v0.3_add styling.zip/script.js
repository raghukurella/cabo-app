const { createClient } = supabase;

const supabaseClient = createClient(
  'https://tshowljfunfshsodwgtf.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRzaG93bGpmdW5mc2hzb2R3Z3RmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMxNDYzMDksImV4cCI6MjA3ODcyMjMwOX0.-bdEZsKrw1V58fW-P80WYczV1K-z3vBvlTiILiGNcrg'
);



async function loadRequiredFields() {
    const { data, error } = await supabaseClient.rpc('get_required_columns', {
      table_name: 'demographics'
    });
  
    if (error) {
      console.error('Error fetching required columns:', error);
      return new Set(); // fallback to empty set
    }
  
    return new Set(data.map(col => col.column_name));
  }  




//  const requiredFields = new Set(
//    columns.filter(col => col.is_nullable === 'NO').map(col => col.column_name)
//  );

let requiredFields = new Set();
let steps = [];
let currentStep = 0;

function validateInput(input) {
    if (!input || !input.required) return true;
  
    const value = input.type === 'checkbox' ? input.checked : input.value.trim();
    if (!value) {
      input.classList.add('invalid');
      input.focus();
      return false;
    }
  
    input.classList.remove('invalid');
    return true;
  }
function renderStep() {
    const allSteps = document.querySelectorAll('.step'); // selects all inputs you've added
    allSteps.forEach((el, index) => {
      el.classList.toggle('hidden', index !== currentStep); // show current, hide others
    });
  
    document.getElementById('prevBtn').disabled = currentStep === 0;
    document.getElementById('nextBtn').textContent =
      currentStep === steps.length - 1 ? 'Submit' : 'Next';
}
function buildInput(labelText, name, type = 'text', options = null) {
    const div = document.createElement('div');
    div.className = 'form-field';
  
    const label = document.createElement('label');
    label.textContent = labelText + (requiredFields.has(name) ? ' *' : '');
    label.setAttribute('for', name);
  
    let input;
    if (type === 'select') {
      input = document.createElement('select');
      options.forEach(opt => {
        const option = document.createElement('option');
        option.value = opt;
        option.textContent = opt;
        input.appendChild(option);
      });
    } else {
      input = document.createElement('input');
      input.type = type;
    }
  
    input.name = name;
    input.id = name;
    if (requiredFields.has(name)) input.required = true;
  
    div.appendChild(label);
    div.appendChild(input);
    return div;
  }

async function loadSteps() {
    // 🔹 1. Fetch required columns from Supabase
    const { data: requiredCols, error } = await supabaseClient.rpc('get_required_columns', {
        table_name: 'demographics'
    });

    if (error) {
        console.error('Error fetching required columns:', error);
        return;
    }


    requiredFields = await loadRequiredFields();

    const container = document.getElementById('questionStep');
    steps = [
        buildInput('First Name', 'first_name', 'text', null, requiredFields),
        buildInput('Last Name', 'last_name', 'text', null, requiredFields),
        buildInput('Email', 'email', 'email', null, requiredFields),
        buildInput('Phone Number', 'phone_number', 'tel', null, requiredFields),
        buildInput('Age', 'age', 'number', null, requiredFields),
        buildInput('Gender', 'gender', 'text', null, requiredFields),
        buildInput('Location', 'location', 'text', null, requiredFields)
        ];
  
    // Load education levels
    supabaseClient
      .from('education_levels')
      .select('value')
      .then(({ data }) => {
        const eduOptions = data.map(d => d.value);
        steps.push(buildInput('Education Level', 'education', 'select', eduOptions));
  
        // Load questions
        return supabaseClient.from('questions').select('id, question_text');
      })
      .then(({ data }) => {
        data.forEach(q => {
          steps.push(buildInput(q.question_text, `question_${q.id}`, 'checkbox'));
        });
  
        // Append all steps to the DOM
        steps.forEach((step, index) => {
          step.classList.add('step');
          if (index !== 0) step.classList.add('hidden');
          container.appendChild(step);
        });
  
        renderStep();
      });
}

async function submitForm() {
  const form = document.getElementById('matchForm');

  const formData = new FormData(form);
  const data = Object.fromEntries(formData.entries());

  const { data: demoData, error: demoError } = await supabaseClient
    .from('demographics')
    .insert([{
      first_name: data.first_name,
      last_name: data.last_name,
      email: data.email,
      phone_number: data.phone_number,
      age: parseInt(data.age),
      gender: data.gender,
      location: data.location,
      education: data.education
    }])
    .select();

  if (demoError) {
    console.error('Demographic insert error:', demoError);
    alert('Failed to submit demographic info.');
    return;
  }

  const demographic_id = demoData[0].id;

  const responses = [];
  for (let [key, value] of formData.entries()) {
    if (key.startsWith('question_')) {
      responses.push({
        demographic_id,
        question_id: parseInt(key.split('_')[1]),
        answer: true
      });
    }
  }

  const { error: responseError } = await supabaseClient
    .from('responses')
    .insert(responses);

  if (responseError) {
    console.error('Response insert error:', responseError);
    alert('Failed to submit responses.');
    return;
  }

  alert('Form submitted successfully!');
  form.reset();
  currentStep = 0;
  renderStep();








  console.log('Form data:', data);












}

document.addEventListener('DOMContentLoaded', () => {
  loadSteps();

  document.getElementById('nextBtn').addEventListener('click', () => {
    const currentStepEl = steps[currentStep];
    const inputs = currentStepEl.querySelectorAll('input, select, textarea');
  
    for (const input of inputs) {
      if (!validateInput(input)) return; // stop if any input is invalid
    }
  
    if (currentStep === steps.length - 1) {
      submitForm();
    } else {
      currentStep++;
      renderStep();
    }
  });

  document.getElementById('prevBtn').addEventListener('click', () => {
    if (currentStep > 0) {
      currentStep--;
      renderStep();
    }
  });
});