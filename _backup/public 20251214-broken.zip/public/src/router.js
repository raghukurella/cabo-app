const routes = {
  "": "pages/landing.html",
  "#/": "pages/landing.html",
  "#/login": "pages/login.html",
  "#/signup": "pages/signup.html",
  "#/profile": "pages/profile.html",
  "#/my-profile": "pages/my-profile.html",
  "#/search": "pages/search.html",
  "#/security": "pages/security.html",
  "#/auth/callback": "callback.html"
};

async function loadPage() {
  const hash = window.location.hash || "#/";
  const page = routes[hash] || routes["#/"];

  const html = await fetch(page).then(res => res.text());

  const app = document.getElementById("app");

  // ✅ Remove previously injected router scripts
  document.querySelectorAll("script[data-router]").forEach(s => s.remove());

  // ✅ Extract scripts BEFORE inserting HTML
  const tempDiv = document.createElement("div");
  tempDiv.innerHTML = html;

  const scripts = tempDiv.querySelectorAll("script");

// ✅ Execute scripts exactly once
scripts.forEach(oldScript => {
  const newScript = document.createElement("script");
  newScript.setAttribute("data-router", "true");

  // ✅ Always force module execution
  newScript.type = "module";

  // ✅ Copy src for external scripts
  if (oldScript.src) {
    newScript.src = oldScript.src;
  }

  // ✅ Copy inline content
  if (oldScript.textContent.trim()) {
    newScript.textContent = oldScript.textContent;
  }

  document.body.appendChild(newScript);
});
}

// ✅ Only ONE startup path
window.addEventListener("hashchange", loadPage);
loadPage(); // run once on initial load