const routes = {
  "": "pages/landing.html",
  "#/": "pages/landing.html",
  "#/login": "pages/login.html",
  "#/signup": "pages/signup.html",
  "#/profile": "pages/profile.html",
  "#/profile-more": "pages/profile-more.html",
  "#/my-profile": "pages/my-profile.html",
  "#/search": "pages/search.html",
  "#/security": "pages/security.html"
};

async function loadPage() {
  const hash = window.location.hash || "#/";
  const page = routes[hash] || routes["#/"];

  const html = await fetch(page).then(res => res.text());

  const app = document.getElementById("app");
  app.innerHTML = html;

// ✅ Execute inline and external scripts inside loaded HTML
const scripts = app.querySelectorAll("script");

scripts.forEach(oldScript => {
  const newScript = document.createElement("script");

  // ✅ Copy all attributes (type, src, async, etc.)
  for (const attr of oldScript.attributes) {
    newScript.setAttribute(attr.name, attr.value);
  }

  // ✅ Copy inline script content
  if (oldScript.textContent) {
    newScript.textContent = oldScript.textContent;
  }

  // ✅ Append so it executes
  document.body.appendChild(newScript);

  // ✅ Remove old script
  oldScript.remove();
});
}

window.addEventListener("hashchange", loadPage);
window.addEventListener("DOMContentLoaded", loadPage);